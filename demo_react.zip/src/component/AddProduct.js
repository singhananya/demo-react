import React,{Component}from 'react';
import ShowProduct from './ShowProduct';
//will Component
class AddProduct extends Component{
    constructor(){
        super();
        this.state={
          prodId:'',
          prodName:'',
          prodPrice: ''
        }
    }

    addProduct=(event)=>{
       //alert("Product Id is "+this.state.prodId+" Product Name is "+this.state.prodName+" Product Price is "+this.state.prodPrice);
       //call Back
      // console.log(this.state);
       this.props.calladdproduct(this.state);
    }
prodIdChange=(event)=>{
  this.setState({
      prodId:event.target.value
  })
}

prodNameChange=(event)=>{
    this.setState({
        prodName:event.target.value
    })
}

prodPriceChange=(event)=>{
    this.setState({
        prodPrice:event.target.value
    })
}
    //Automatically
    render(){
        //VIEW
        return(
            <div>
                <h1>Add Product .....</h1>
               
                <table border="1">
                    <tr>
                        <td>Product Id</td>
                        <td><input type="text" value={this.state.prodId} onChange={this.prodIdChange}></input></td>
                    </tr>
                    <tr>
                        <td>Product Name</td>
                        <td><input type="text" value={this.state.prodName} onChange={this.prodNameChange}></input></td>
                    </tr>
                    <tr>
                        <td>Product Price</td>
                        <td><input type="text" value={this.state.prodPrice} onChange={this.prodPriceChange}></input></td>
                    </tr>
                    <tr>
                        <td><button onClick={this.addProduct}>Add Product</button></td>
                       
                    </tr>
                </table>
            </div>
        )
    }}

    export default AddProduct;