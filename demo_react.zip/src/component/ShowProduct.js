import React,{Component} from 'react';

class ShowProduct extends Component{
    
 deleteProduct=(da)=>{
      
 }
    render(){
        //const mydata=["A","B","C"];
        const header=<tr><th>Product Id</th><th>Product Name</th>
        <th>Product Price</th> <th>Action</th></tr>;
        const yprint =this.props.mydata.map((prod,index)=>
        <tr><td>{prod.prodId}</td><td>{prod.prodName}</td>
        <td>{prod.prodPrice}</td><td><button onClick={()=>this.deleteProduct(index)}>Delete</button></td></tr>);

        return(
            <div>
                <h2>Product Show All</h2>
                <table border="1">
                    {header}
                    {yprint}
                </table>
              
                
            </div>
        )
    }}
    export default ShowProduct;