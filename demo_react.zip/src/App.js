import logo from './logo.svg';
import './App.css';
import AddProduct from './component/AddProduct';
import ShowProduct from './component/ShowProduct';
import React,{ Component } from 'react';

class App extends Component {
  constructor(){
    super();
    this.state={
        products:[
         {"prodId":1001,"prodName":"Rice","prodPrice":67},
         {"prodId":1002,"prodName":"Mobile","prodPrice":6887.88},
         {"prodId":1003,"prodName":"Veg","prodPrice":167}
        ]
    }
}
addData=(event)=>{
 let addprod=this.state.products.push(event);
 this.setState({addprod});
}
render(){
  return (
    <div className="App">
      <h1>Welcome to React JS....</h1>
      <AddProduct calladdproduct={this.addData}></AddProduct>
      <ShowProduct mydata={this.state.products}></ShowProduct>
      </div>
  );
}
}

export default App;
